# Student package

Keep assets/ and student/ together. Install student/training-requirements.txt before the event. Open a terminal in student/, then run python -m jupyterlab team-notebook.ipynb. Train/edit the neural network with student/train_repair.py, then edit repair.py and run python check_submission.py from student/. Generated reports go into student/results/. One laptop per team; no paid account or API key. Follow student/TEAM_BRIEF.md. Host solutions and confirmation scenes are excluded.
